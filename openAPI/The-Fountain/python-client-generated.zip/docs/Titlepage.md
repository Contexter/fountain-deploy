# Titlepage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title_page_id** | **int** | Note: This is a Primary Key.&lt;pk/&gt; | 
**script_id** | **int** |  | [optional] 
**text** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

