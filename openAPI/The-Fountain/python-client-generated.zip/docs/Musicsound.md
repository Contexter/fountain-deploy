# Musicsound

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_sound_id** | **int** | Note: This is a Primary Key.&lt;pk/&gt; | 
**scene_id** | **int** |  | [optional] 
**cue** | **str** |  | [optional] 
**description** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

