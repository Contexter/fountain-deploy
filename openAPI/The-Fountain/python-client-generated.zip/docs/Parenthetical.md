# Parenthetical

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parenthetical_id** | **int** | Note: This is a Primary Key.&lt;pk/&gt; | 
**dialogue_id** | **int** |  | [optional] 
**original_text** | **str** |  | [optional] 
**modernized_text** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

