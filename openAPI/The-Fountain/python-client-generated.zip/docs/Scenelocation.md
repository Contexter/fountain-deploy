# Scenelocation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location_id** | **int** | Note: This is a Primary Key.&lt;pk/&gt; | 
**description** | **str** |  | 
**historical_cultural_significance** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

