# Crossreferences

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cross_reference_id** | **int** | Note: This is a Primary Key.&lt;pk/&gt; | 
**scene_id** | **int** |  | [optional] 
**referenced_scene_id** | **int** |  | [optional] 
**description** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

