# Action

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**action_id** | **int** | Note: This is a Primary Key.&lt;pk/&gt; | 
**scene_id** | **int** |  | [optional] 
**character_id** | **int** |  | [optional] 
**original_text** | **str** |  | [optional] 
**modernized_text** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

