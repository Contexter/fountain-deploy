# Characterrelationship

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**relationship_id** | **int** | Note: This is a Primary Key.&lt;pk/&gt; | 
**character1_id** | **int** |  | [optional] 
**character2_id** | **int** |  | [optional] 
**relationship_type** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

